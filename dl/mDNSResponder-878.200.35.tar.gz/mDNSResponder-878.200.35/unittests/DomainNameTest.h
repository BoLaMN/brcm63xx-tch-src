#ifndef DomainNameTest_h
#define DomainNameTest_h

#include "unittest.h"
int DomainNameTest(void);

#endif /* DomainNameTest_h */
