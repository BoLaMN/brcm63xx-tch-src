//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ControlPanel.rc
//
#define IDR_APPLET                      131
#define IDR_APPLET_PAGE1                131
#define IDS_APPLET_DESCRIPTION          132
#define IDR_APPLET_PAGE2                132
#define IDR_SECRET                      133
#define IDR_APPLET_PAGE3                134
#define IDR_APPLET_PAGE4                135
#define IDR_APPLET_PAGE5                136
#define IDI_FAILURE                     140
#define IDI_SUCCESS                     141
#define IDI_ENERGY_SAVER				142
#define IDR_ADD_BROWSE_DOMAIN           143
#define IDR_POWER_MANAGEMENT_WARNING	144
#define IDS_REINSTALL					145
#define IDS_REINSTALL_CAPTION			146
#define IDS_APPLET_NAME					147
#define IDS_APPLET_TOOLTIP				148
#define IDC_HOSTNAME                    1000
#define IDC_USERNAME					1001
#define IDC_PASSWORD					1002
#define IDC_ADVERTISE_SERVICES			1003
#define IDC_BUTTON1                     1004
#define IDC_COMBO1                      1005
#define IDC_CHECK1                      1006
#define IDC_COMBO2                      1007
#define IDC_EDIT2                       1008
#define IDC_SECRET                      1009
#define IDC_COMBO3                      1010
#define IDC_FAILURE                     1011
#define IDC_SUCCESS                     1012
#define IDC_SECRET_NAME                 1013
#define IDC_NAME                        1014
#define IDC_KEY                         1015
#define IDC_LIST1                       1016
#define IDC_BROWSE_LIST                 1017
#define IDC_BUTTON2                     1018
#define IDC_REMOVE_BROWSE_DOMAIN        1019
#define IDC_ADD_BROWSE_DOMAIN           1020
#define IDC_POWER_MANAGEMENT            1021
#define IDC_ADVERTISE_SMB	            1022
#define IDC_ENERGY_SAVER				1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
