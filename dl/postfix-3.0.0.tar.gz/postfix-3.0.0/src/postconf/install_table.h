    VAR_CONFIG_DIR, DEF_CONFIG_DIR, &var_config_dir, 1, 0,
	VAR_DEBUG_COMMAND, "", &var_debug_command, 1, 0,
