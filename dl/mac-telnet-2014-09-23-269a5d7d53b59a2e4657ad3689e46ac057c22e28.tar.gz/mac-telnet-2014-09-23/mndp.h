#ifndef _MNDP_H
#define _MNDP_H

int mndp(int timeout, int batch_mode);

#endif
