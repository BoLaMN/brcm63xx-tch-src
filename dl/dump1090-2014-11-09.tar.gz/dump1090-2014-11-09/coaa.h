// coaa.h configuration file for Plane Plotter Uploader
//
// You MUST apply via the COAA website for your own personal version of this file
// Do not disclose the contents of this file to anyone thereafter as it uniquely
// identifies you to the PlanePlotter system 
//
