int __acl_extended_file(const char *path_p,
			ssize_t (*)(const char *, const char *,
				    void *, size_t));
