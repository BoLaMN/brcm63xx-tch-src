/*
 * ID: 1
 * Command: Connect
 */

#define MBIM_CMD_DSS_CONNECT	1

