/*
 * ID: 1
 * Command: Get
 */

#define MBIM_CMD_MS_FIRMWARE_ID_GET	1

struct mbim_ms_firmware_id_get_r =
	struct mbim_uuid firmwareid;
}

