If you submit a pull request, please adhere to Contributor Guidelines:

https://github.com/micropython/micropython-lib/wiki/ContributorGuidelines
