void res_init_startup();
void res_init_cleanup();

void __putshort(register u_short s, register u_char *msgp);
void __putlong(register u_long l, register u_char *msgp);
