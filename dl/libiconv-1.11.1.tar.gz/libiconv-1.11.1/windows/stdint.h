/* The system doesn't have <stdint.h>.
   Here are the bare minimum definitions.  */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
