#!/bin/sh
autoreconf -i
