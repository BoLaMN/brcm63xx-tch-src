#!/bin/bash


make clean; make bcm947x_ddwrt

make clean; make bcm947x_backfire

make clean; make ar71xx_backfire

make clean; make ar231x_backfire

make clean; make bcm947x_backfire

make clean; make bcm2708

make clean; make bcm47xx

make clean; make bcm63xx

make clean; make ar7xxx

make clean; make ar231x

make clean
